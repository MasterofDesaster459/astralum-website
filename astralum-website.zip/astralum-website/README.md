# ASTRALUM – Website-Paket

Dies ist eine statische Website mit HTML, CSS und JavaScript. Der Farb-Rechner läuft lokal im Browser; es gibt keinen Server, keine Datenbank und keine Konten.

## Dateien
- `index.html` – Startseite und Farb-Rechner
- `styles.css` – responsives Design
- `script.js` – fiktive Farblogik und Interaktionen
- `impressum.html` – rechtliche Vorlage, vor Veröffentlichung ausfüllen
- `datenschutz.html` – Datenschutzvorlage, vor Veröffentlichung anpassen
- `assets/favicon.svg` – Icon

## Lokal testen
Öffne `index.html` in einem aktuellen Browser. Für einen lokalen Webserver (optional) kannst du im Ordner z. B. `python -m http.server 8000` ausführen und dann `http://localhost:8000` öffnen.

## Kostenlos mit GitHub Pages veröffentlichen
1. Lege ein GitHub-Konto an bzw. melde dich an.
2. Erstelle ein neues **öffentliches** Repository, z. B. `astralum-website`.
3. Lade alle Dateien und den Ordner `assets` in das Repository hoch (die Dateien müssen im Repository-Hauptverzeichnis liegen).
4. Öffne **Settings → Pages**.
5. Wähle unter Build and deployment die Veröffentlichung aus dem Branch `main` und dem Ordner `/ (root)`, danach Save.
6. Nach der Veröffentlichung zeigt GitHub Pages die öffentliche URL an, typischerweise `https://DEIN-NAME.github.io/astralum-website/`.

GitHub Pages unterstützt statische Websites und benutzerdefinierte Domains. Details:
- https://pages.github.com/
- https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site

## Eigene Domain `astralum.de`
Die Verfügbarkeit wurde in diesem Paket nicht bestätigt. Prüfe sie bei DENIC:
https://webwhois.denic.de/
Wenn verfügbar, registriere die Domain über einen Registrar deiner Wahl. Danach:
1. Füge die Domain in GitHub unter **Settings → Pages → Custom domain** hinzu.
2. Folge den aktuellen DNS-Anweisungen von GitHub und deinem Registrar. Für die Hauptdomain sind üblicherweise A/AAAA- oder ALIAS/ANAME-Einträge nötig; für `www` typischerweise ein CNAME.
3. Aktiviere HTTPS in den Pages-Einstellungen, sobald die Domain korrekt eingerichtet ist.
4. DNS-Änderungen können bis zu 24 Stunden benötigen.

Wichtig: DNS-Werte aus der GitHub-Dokumentation übernehmen, nicht raten. Richte die Domain in GitHub ein, bevor du DNS auf GitHub Pages zeigst.

## Vor öffentlichem Start unbedingt erledigen
- `impressum.html`: Platzhalter ersetzen und vollständige Betreiberangaben eintragen.
- `datenschutz.html`: Hosting, Protokolldaten und externe Ressourcen anhand des tatsächlichen Betriebs korrekt beschreiben. Diese Vorlage ist noch nicht rechtsfertig.
- Prüfe Namen und Domain auf mögliche Marken-/Namensrechte.
- Die CSS-Datei verwendet derzeit Google Fonts extern. Bei Bedarf Schriftarten lokal hosten.
- ASTRALUM wird als fiktive Unterhaltung gekennzeichnet. Keine Versprechen über reale Zukunftsvorhersagen oder wissenschaftlich bestätigte Eigenschaften machen.

## Modellhinweis
Die Farbauswahl nutzt eine deterministische Hashfunktion aus Geburtsdatum, Beobachtertyp, Periodennummer und einem frei wählbaren Randomisierungsparameter. Der Geburtszeitpunkt dient nur als Initialwert; daraus werden keine tatsächlichen Aussagen über Persönlichkeit oder Zukunft abgeleitet. Die mathematischen und astrologischen Elemente sind fiktional.
