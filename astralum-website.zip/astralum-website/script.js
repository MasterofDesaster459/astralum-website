const COLORS = [
 {name:"Grün",hex:"#27865A",trait:"Regeneration & Erneuerung",description:"Grün steht in diesem erfundenen Universum für den Kreislauf des Werdens. Seine Bedeutung ist nicht festgeschrieben – sie kann sich mit jeder Periode wandeln.",tags:["Erneuerung","Zyklus","Wachstum"]},
 {name:"Pink",hex:"#E65DAB",trait:"Resonanz & relationale Mehrdeutigkeit",description:"Pink symbolisiert Verbindungen, die sich immer wieder neu ordnen. Es erinnert daran, dass Bedeutung oft zwischen Perspektiven entsteht.",tags:["Resonanz","Wandel","Neugier"]},
 {name:"Türkis",hex:"#28A9A2",trait:"Übergang & Beobachterbindung",description:"Türkis markiert in der fiktiven Farbphilosophie die Schwelle zwischen zwei Zuständen – einen Übergang, dessen Richtung vom Blickwinkel abhängt.",tags:["Übergang","Perspektive","Bewegung"]},
 {name:"Goldgelb",hex:"#E4B735",trait:"Umordnung & Möglichkeit",description:"Goldgelb steht für die Neuordnung vertrauter Muster. Es ist das Symbol für eine Möglichkeit, die erst durch Interpretation Kontur erhält.",tags:["Möglichkeit","Wandel","Neubeginn"]},
 {name:"Violett",hex:"#8056B3",trait:"Mehrdeutigkeit & Überlagerung",description:"Violett verkörpert mehrere mögliche Deutungen zur selben Zeit. Keine davon wird dadurch automatisch wahrer als die anderen.",tags:["Paradox","Tiefe","Fantasie"]},
 {name:"Koralle",hex:"#E77961",trait:"Transformation & vorläufige Identität",description:"Koralle steht für Identitäten im Wandel. Was eben noch eindeutig schien, kann im nächsten Zyklus eine andere Bedeutung erhalten.",tags:["Transformation","Mut","Neuanfang"]},
 {name:"Kobaltblau",hex:"#3566D8",trait:"Ordnung & Distanz",description:"Kobaltblau ist das Symbol für Struktur und Abstand – eine Einladung, Muster zu betrachten, ohne sie sofort erklären zu müssen.",tags:["Struktur","Klarheit","Distanz"]},
 {name:"Smaragd",hex:"#1DAA82",trait:"Verbindung & Ausgleich",description:"Smaragd steht für das Suchen nach Gleichgewicht in einem Universum, dessen Zuordnungen nie für immer stillstehen.",tags:["Ausgleich","Verbindung","Ruhe"]},
 {name:"Magenta",hex:"#D52CA7",trait:"Intensität & kreative Spannung",description:"Magenta repräsentiert die kreative Spannung zwischen dem Bekannten und dem noch Unbenannten.",tags:["Intensität","Kreativität","Spannung"]},
 {name:"Silber",hex:"#A8B7D5",trait:"Reflexion & Perspektivwechsel",description:"Silber spiegelt das Beobachten selbst: Jede Deutung erzählt auch etwas darüber, wer gerade hinsieht.",tags:["Reflexion","Blickwinkel","Neugier"]},
 {name:"Indigo",hex:"#4541A5",trait:"Muster & verborgene Ordnung",description:"Indigo symbolisiert die menschliche Suche nach Ordnung in Zufällen. Ein Muster kann faszinieren, ohne ein Beweis zu sein.",tags:["Muster","Suche","Vorstellung"]},
 {name:"Bernstein",hex:"#D98A32",trait:"Impuls & Veränderung",description:"Bernstein steht für den Moment, in dem eine neue Deutung einen Impuls gibt – als Symbol, nicht als Vorhersage.",tags:["Impuls","Energie","Veränderung"]}
];
const $ = (s) => document.querySelector(s);
const form = $("#colorForm");
const periodInput = $("#period");
const periodOutput = $("#periodOutput");
const seedInput = $("#seed");
const dateInput = $("#birthDate");
const observerInput = $("#observer");
function hashString(text){let h=2166136261;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;}
function getIndex(date, observer, period, seed){
  // Deterministische Pseudozufallszuordnung: das Datum dient nur als Startwert.
  const h=hashString(`${date}|${observer}|${period}|${seed}|ASTRALUM-v1`);
  return h % COLORS.length;
}
function renderResult(){
  const date=dateInput.value || "2000-01-01";
  const observer=observerInput.value;
  const period=Number(periodInput.value);
  const seed=String(seedInput.value || "0");
  const color=COLORS[getIndex(date,observer,period,seed)];
  $("#colorName").textContent=color.name;
  $("#colorName").style.color=color.hex;
  $("#colorTrait").textContent=color.trait;
  $("#colorDescription").textContent=color.description;
  $("#resultSwatch").style.background=`radial-gradient(circle at 30% 25%, #ffffff88, ${color.hex} 43%, #11152f 100%)`;
  $("#resultSwatch").style.boxShadow=`0 0 45px ${color.hex}55, inset -12px -15px 25px rgba(12,10,55,.3)`;
  $("#periodOutput").textContent=period;
  $("#periodMeta").textContent=`Periode ${period}`;
  $("#observerMeta").textContent=`Beobachter: ${{short:"Kurzperiodisch",medium:"Mittel",long:"Langperiodisch"}[observer]}`;
  $("#seedMeta").textContent=`Startwert ${seed}`;
  $("#traitTags").replaceChildren(...color.tags.map(tag=>{const span=document.createElement("span");span.textContent=tag;return span;}));
  $("#copyStatus").textContent="";
  $("#result").dataset.color=color.name;
}
form.addEventListener("submit",e=>{e.preventDefault();renderResult();$("#result").scrollIntoView({behavior:"smooth",block:"nearest"});});
[dateInput,observerInput,periodInput,seedInput].forEach(el=>el.addEventListener("input",renderResult));
$("#randomSeed").addEventListener("click",()=>{seedInput.value=String(Math.floor(Math.random()*1000000));renderResult();});
$("#shareResult").addEventListener("click",async()=>{
 const text=`Meine fiktive ASTRALUM-Farbe ist ${$("#colorName").textContent}: ${$("#colorTrait").textContent}. Periode ${periodInput.value}. ASTRALUM ist ein kreatives Gedankenexperiment, keine wissenschaftliche Vorhersage.`;
 try{await navigator.clipboard.writeText(text);$("#copyStatus").textContent="Ergebnis wurde kopiert.";}
 catch{const area=document.createElement("textarea");area.value=text;document.body.appendChild(area);area.select();const ok=document.execCommand("copy");area.remove();$("#copyStatus").textContent=ok?"Ergebnis wurde kopiert.":"Kopieren nicht möglich – bitte Text manuell markieren.";}
});
const library=$("#colorLibrary");
COLORS.forEach(color=>{
 const card=document.createElement("article");card.className="color-card";
 const dot=document.createElement("div");dot.className="color-dot";dot.style.setProperty("--swatch",color.hex);
 const title=document.createElement("h3");title.textContent=color.name;
 const desc=document.createElement("p");desc.textContent=color.trait;
 card.append(dot,title,desc);library.append(card);
});
const menuToggle=$("#menuToggle"),nav=$("#mainNav");
menuToggle.addEventListener("click",()=>{const open=nav.classList.toggle("open");menuToggle.setAttribute("aria-expanded",String(open));});
nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>{nav.classList.remove("open");menuToggle.setAttribute("aria-expanded","false");}));
renderResult();
